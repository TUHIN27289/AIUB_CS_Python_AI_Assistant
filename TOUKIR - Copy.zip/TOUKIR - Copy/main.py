from datetime import datetime
import speech_recognition as sr
import pyttsx3
import webbrowser
import wikipedia
import wolframalpha
import requests
######
import matplotlib.pyplot as plt
import numpy as np
import math



######
#speech engine initialisation
engine=pyttsx3.init()
voices=engine.getProperty('voices')
engine.setProperty('voices',voices[0].id)  # 0 male 1 female
activationword='computer'#single word

#configure webbrowser
#set the path

chrome_path=r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
webbrowser.register('Chrome',None,webbrowser.BackgroundBrowser(chrome_path))


###########################

def draw_shape(shape, params):
    if shape == 'circle':
        if len(params) == 1:
            radius = float(params[0])
            draw_circle(radius)
        else:
            speak('Invalid parameters for drawing a circle.')
    
    elif shape == 'triangle':
        if len(params) == 6:
            points = [(float(params[i]), float(params[i+1])) for i in range(0, 6, 2)]
            draw_triangle(points)
        else:
            speak('Invalid parameters for drawing a triangle.')
    
    elif shape == 'rectangle':
        if len(params) == 2:
            width, height = float(params[0]), float(params[1])
            draw_rectangle(width, height)
        else:
            speak('Invalid parameters for drawing a rectangle.')
    
    elif shape == 'ellipse':
        if len(params) == 2:
            a, b = float(params[0]), float(params[1])
            draw_ellipse(a, b)
        else:
            speak('Invalid parameters for drawing an ellipse.')
    
    else:
        speak('Shape not supported.')

def draw_circle(radius):
    theta = np.linspace(0, 2 * np.pi, 100)
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    
    plt.figure()
    plt.plot(x, y)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.xlabel("X-axis")
    plt.ylabel("Y-axis")
    plt.title(f"Circle with radius {radius}")
    plt.grid(True)
    plt.show()

def draw_triangle(points):
    x = [p[0] for p in points] + [points[0][0]]
    y = [p[1] for p in points] + [points[0][1]]
    
    plt.figure()
    plt.plot(x, y)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.xlabel("X-axis")
    plt.ylabel("Y-axis")
    plt.title("Triangle")
    plt.grid(True)
    plt.show()

def draw_rectangle(width, height):
    x = [0, width, width, 0, 0]
    y = [0, 0, height, height, 0]
    
    plt.figure()
    plt.plot(x, y)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.xlabel("X-axis")
    plt.ylabel("Y-axis")
    plt.title("Rectangle")
    plt.grid(True)
    plt.show()

def draw_ellipse(a, b):
    theta = np.linspace(0, 2 * np.pi, 100)
    x = a * np.cos(theta)
    y = b * np.sin(theta)
    
    plt.figure()
    plt.plot(x, y)
    plt.gca().set_aspect('equal', adjustable='box')
    plt.xlabel("X-axis")
    plt.ylabel("Y-axis")
    plt.title("Ellipse")
    plt.grid(True)
    plt.show()










############################




##########   handle

def handle_draw_circle():
    speak('Please provide the radius for the circle.')
    radius_command = parsecommand().lower()
    try:
        radius = float(radius_command)
        draw_shape('circle', [str(radius)])
    except ValueError:
        speak('Invalid radius. Please try again.')

# Handle drawing a triangle
def handle_draw_triangle():
    points = []

    # Ask for the first point
    speak("Please provide the first point:")
    first_point = parsecommand().lower()
    x1, y1 = extract_coordinates(first_point)
    if x1 is not None and y1 is not None:
        points.append((x1, y1))
    else:
        speak("Invalid point. Please try again.")
        return

    # Ask for the second point
    speak("Please provide the second point:")
    second_point = parsecommand().lower()
    x2, y2 = extract_coordinates(second_point)
    if x2 is not None and y2 is not None:
        points.append((x2, y2))
    else:
        speak("Invalid point. Please try again.")
        return

    # Ask for the third point
    speak("Please provide the third point:")
    third_point = parsecommand().lower()
    x3, y3 = extract_coordinates(third_point)
    if x3 is not None and y3 is not None:
        points.append((x3, y3))
    else:
        speak("Invalid point. Please try again.")
        return

    if len(points) == 3:
        draw_shape('triangle', points)
    else:
        speak("Not enough valid points. Please try again.")

def extract_coordinates(command):
    x = y = None
    if 'x' in command and 'y' in command:
        x_str = command.split('x')[1].split()[0]
        y_str = command.split('y')[1].split()[0]
        try:
            x = float(x_str)
            y = float(y_str)
        except ValueError:
            pass
    return x, y


'''
def handle_draw_triangle():
    speak('Please provide the three points (x, y) for the triangle in the format: x1 y1 x2 y2 x3 y3')
    points_command = parsecommand().lower().split()
    try:
        points = [(float(points_command[i]), float(points_command[i+1])) for i in range(0, 6, 2)]
        draw_shape('triangle', points)
    except ValueError:
        speak('Invalid points. Please try again.')

# Handle drawing a rectangle
def handle_draw_rectangle():
    speak('Please provide the width and height for the rectangle in the format: width height')
    dimensions_command = parsecommand().lower().split()
    try:
        width, height = float(dimensions_command[0]), float(dimensions_command[1])
        draw_shape('rectangle', [str(width), str(height)])
    except ValueError:
        speak('Invalid dimensions. Please try again.')

'''


# Handle drawing an ellipse
def handle_draw_ellipse():
    speak('Please provide the two semi-axes lengths (a and b) for the ellipse in the format: a b')
    axes_command = parsecommand().lower().split()
    try:
        a, b = float(axes_command[0]), float(axes_command[1])
        draw_shape('ellipse', [str(a), str(b)])
    except ValueError:
        speak('Invalid semi-axes lengths. Please try again.')



def handle_draw_command(command):
    if 'circle' in command:
        handle_draw_circle()
    elif 'triangle' in command:
        handle_draw_triangle()
    elif 'rectangle' in command:
        handle_draw_rectangle()
    elif 'ellipse' in command:
        handle_draw_ellipse()
    else:
        speak('Shape not supported.')

##################

def get_weather_forecast(city):
    base_url = 'https://api.openweathermap.org/data/2.5/weather'
    api_key = '9b1a2a65025126596ac8d00382289a37'
    params = {'q': city, 'appid': api_key}

    try:
        response = requests.get(base_url, params=params)
        data = response.json()

        if data['cod'] == 200:
            weather = data['weather'][0]['description']
            temperature = data['main']['temp']
            humidity = data['main']['humidity']

            forecast = f"The weather in {city} is {weather}. "
            forecast += f"The temperature is {temperature:.1f}°C with {humidity}% humidity."
            return forecast
        else:
            return f"Unable to fetch weather forecast for {city}."

    except requests.exceptions.RequestException as e:
        return f"An error occurred while fetching the weather forecast for {city}."


def check_prime(number):
    query = f"is {number} a prime number?"
    result = search_wolframAlpha(query)
    return result



def ListOrDict(var):
    if isinstance (var,list):
        return var[0]['plaintext']
    else:
        return var['plaintext']

#Wolfram Alpha Client
appId='7TGKK6-7JKWLK963A'
wolframclient=wolframalpha.Client(appId)


def search_wolframAlpha(query):
    response=wolframclient.query(query)
    if response['@success']=='false':
        return 'could not computer'
    
    #query resolved
    else:
        result=''
        #question
        pod0=response['pod'][0]
        pod1=response['pod'][1]
        #may contains the value,has the highiest confidence value
        #if it's primary or has the title of result or definition,then it's the official result 
        if(('result')in pod1['@title'].lower()) or (pod1.get('@primary','false')=='true')or('definition' in pod1['@title'].lower()):
            #get the result
            result=ListOrDict(pod1['subpod'])
            #remove the brackted section
            return result.split('(')[0]
        else:
            question=ListOrDict(pod0['subpod'])
            #remove the brackted section
            return question.split('(')[0]
        #search wikipedia instead
        speak('computation failed.querying universal databank.')
        return search_wikipedia(question)


    
def search_wikipedia(query=' '):
    searchResult=wikipedia.search(query)
    if not searchResult:
        print('no wikipedia Result')
        return 'no result received'
    try:
        wikiPage=wikipedia.page(searchResult[0])
    except wikipedia.DisambiguationError as error:
        wikiPage=wikipedia.page(error.options[0])
    print(wikiPage.title)
    wikiSummary=str(wikiPage.summary)
    #return wikiSummary
    speak(wikiSummary)



def speak(text, rate=120):
    engine.setProperty('rate',rate)
    engine.say(text)
    engine.runAndWait()


def parsecommand():
    listener=sr.Recognizer()
    print('listening for command')
    #with sr.Microphone as source:
    with sr.Microphone() as source:
    # Your code inside the 'with' block

        listener.pause_threshold=2
        input_speech=listener.listen(source)

    try:
        print('Reconizing Speech .............')
        query=listener.recognize_google(input_speech,language='en_gb')
        print(f'The input speech was:{query}')
    except Exception as exception:
        print('I didnot quite catch that')
        speak('I didnot quite catch that')
        print(exception)
        return 'none'
    return query

if __name__ == '__main__':
    speak('All system nominal.')
    while True:
        # Parse as a list
        #query=parsecommand().lower().spilt()
        query = parsecommand().lower().split()
        if query[0]==activationword:
            
            query.pop(0)
            # list commands
            if query[0]=='say':
                if'hello' in query:
                    speak('Greetings,All')
                else:
                    query.pop()#remove say
                    speech=' '.join(query)
                    speak(speech) 
            
            if query[0]=='go' and query[1]=='to':
                speak('openning')
                query=' '.join(query[2:])
                webbrowser.get('Chrome').open_new(query)
            

            # wikipedia
            if query[0]=='wikipedia':
                query=' '.join(query[1:])
                speak('quering the universal Databank')
                speak(search_wikipedia(query))


            # Wolfram Alpha 
            if query[0]=='compute'or query[0]=='computer':
                query=' '.join(query[1:])
                speak('computing')
                try:
                    result=search_wolframAlpha(query)
                    speak(result)
                except:
                    speak('unable to compute')

            # Check if a number is prime
            if query[0] == 'check' and query[1] == 'prime':
                number = query[2]
                speak(f"Checking if {number} is a prime number...")
                result = check_prime(number)
                speak(result)
            
            if 'weather' in query:
                cities = [word for word in query if word != 'weather']
                if len(cities) > 0:
                    speak('Fetching weather forecast...')
                    for city in cities:
                        forecast = get_weather_forecast(city)
                        speak(forecast)
                else:
                    speak('Please provide city names for weather forecast.')
            
            
            


            '''
                    if 'weather' in query:
                cities = [word for word in query if word != 'weather']
                if len(cities) > 0:
                    speak('Fetching weather forecast...')
                    for city in cities:
                        forecast = get_weather_forecast(city)
                        speak(forecast)
                else:
                    speak('Please provide city names for weather forecast.')
                    
                #'''
            #note taking
            if query[0]=='log':
                speak('ready to take your note')
                newnote=parsecommand().lower()
                now=datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
                with open('note_%s.txt'%now,'w') as newFile:
                    newFile.write(newnote)
                speak('NOTE WRITTEN')

            if query=='exit':
                speak('good bye')
                break

#####
            '''

             # Handle different shape commands
            if query[0] == 'draw':
                shape = query[1]
                params = query[2:]
                draw_shape(shape, params)

            '''
           
            
 #####      
            #  # Handle 'draw' commands
            if query[0] == 'draw':
                handle_draw_command(query)    
            
             
            


